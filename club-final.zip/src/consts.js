export const MAIN_ROUTE = "/";
export const CONNECT_ROUTE = "/connect";
