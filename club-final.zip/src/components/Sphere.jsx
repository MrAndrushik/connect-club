import Spline from "@splinetool/react-spline";

export default function Sphere() {
    return (
        <div>
            {/* <Spline scene="https://draft.spline.design/NzcV-Ex9j3z1TjHJ/scene.spline" /> */}
            <Spline scene="https://prod.spline.design/cjbUufY93RTELhWx/scene.spline" />
        </div>
    );
}
